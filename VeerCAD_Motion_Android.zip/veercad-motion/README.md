# VeerCAD Motion (Android)

Phone app that opens STEP / STL assemblies and animates user-defined joints.

Every push to `main` builds the APK on GitHub Actions. Download it from **Releases**
(or Actions -> latest run -> Artifacts). Install it on the phone (allow "install unknown apps").

The 3D library (three.js r128) is downloaded during the build, so the app works offline.
